#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>
#include <stdlib.h>

#include "funciones.h"

void probarPrimitivasUno(FILE *fpPant);

void probarPrimitivasDos(FILE *fpPant);



#endif // MAIN_H_

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

