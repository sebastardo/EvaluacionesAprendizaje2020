#ifndef MAIN_H__
#define MAIN_H__

#include <iostream>
#include <sstream>

using namespace std;


#include "pers.h"




#endif

