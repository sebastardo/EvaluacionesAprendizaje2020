#ifndef MAIN_H_
#define MAIN_H_

#include <iostream>

#include "Prisma.h"

using namespace std;


#endif // MAIN_H_

