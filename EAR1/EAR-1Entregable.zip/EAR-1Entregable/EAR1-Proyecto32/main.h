#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>
#include <stdlib.h>

#include "funciones.h"


void probarCadenas(FILE *fpPant);

void probarMatrices(FILE *fpPant);

void probarArchivosYPila(FILE *fpPant);


#endif // MAIN_H_

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

