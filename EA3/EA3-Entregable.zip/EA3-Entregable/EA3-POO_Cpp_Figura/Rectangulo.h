/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/

#ifndef RECTANGULO_H_
#define RECTANGULO_H_








#endif // RECTANGULO_H_
